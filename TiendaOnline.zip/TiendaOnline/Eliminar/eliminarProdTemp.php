<?php session_start();?>
<?php
require_once('../conexion/conexion.php');

if($_POST['action'] == 'del_product_detalle'){
    if(empty($_POST['id_detalle'])){

        echo "erro";

    }else{
        $id_detalle=$_POST['id_detalle'];
        
        $session_id= session_id();

        $consultas= mysqli_query($conectar,"CALL del_detalle_temp($id_detalle,'$session_id')"); 
        $resulta= mysqli_num_rows($consultas);
        $detalles='';
        $subtotal =0;
        $total =0;
        $arrayData =array();
        if($resulta > 0){

        while ($data =mysqli_fetch_assoc($consultas)){
            $precio_total= round($data['Canti'] * $data['precio_tmp'],2);
            $subtotal=round($subtotal + $precio_total,2);
            $total =round($total + $precio_total,2);

            $detalles.='<tr>
                                <td>'.$data['Cod_prod'].'</td>
                                <td class ="text-rigth">'.$data['Canti'].'</td>                         
                                <td class ="text-left">'.$data['precio_tmp'].'</td>
                                <td colspan="1">'.$data['descripcion'].'</td>   
                                <td class ="text-rigth">'.$precio_total.'</td>
                                <td class="text-rigth">
                                <button class ="link_delete" onclick="event.preventDefault();
								del_product_detalle ('.$data['correlativo'].')";>eliminar</button>
								</td>
                                </tr>';
        }
        $detalletabla ='
        <tr>
        <td class="text-right" colspan=4>SUBTOTAL $</td>
        <td class="text-left">'.$subtotal.'</td>
        <td></td>
    </tr>
    
    <tr>
        <td class="text-right" colspan=4>TOTAL $</td>
        <td class="text-left">'.$total.'</td>
        <td></td>
    </tr>';
    $arrayData['detalle'] =$detalles;
    $arrayData['totales'] =$detalletabla;
    echo json_encode($arrayData,JSON_UNESCAPED_UNICODE);

    
        

 
}else{
    echo 'error';
    mysqli_close($conectar);
}
exit;
}
}

    

?>
