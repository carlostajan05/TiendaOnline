<?php session_start();?>
<?php
require ("../conexion/conexion.php");


    $p= $_POST['ID'];

    $consultas= "DELETE FROM clientes WHERE ID=$p";   
    $resulta= $conectar->query($consultas);
    if ($resulta) {
        echo "<SCRIPT >
    alert('!PRODUCTO ELIMINADO¡');
    document.location=('../Vistas/productos.php');
    </SCRIPT>";
    } else {
    
        echo "<SCRIPT >
    alert('!ERROR AL ELIMINAR EL PRODUCTO¡');
    document.location=('../Vistas/productos.php');
    
    </SCRIPT>";
    }


?>

