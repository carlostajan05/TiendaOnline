<?php session_start();?>
<?php
require ("../conexion/conexion.php");


    $producto_id= $_POST['idprod'];

    $consultas= "DELETE FROM productos WHERE idProductos=$producto_id";   
    $resulta= $conectar->query($consultas);
    if ($resulta) {
        echo "<SCRIPT >
    alert('!PRODUCTO ELIMINADO¡');
    document.location=('../Vistas/productos.php');
    </SCRIPT>";
    } else {
    
        echo "<SCRIPT >
    alert('!ERROR AL ELIMINAR EL PRODUCTO¡');
    document.location=('../Vistas/productos.php');
    
    </SCRIPT>";
    }


?>


