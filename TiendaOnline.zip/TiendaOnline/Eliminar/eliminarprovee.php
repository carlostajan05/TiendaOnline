<?php session_start();?>
<?php
require ("../conexion/conexion.php");


    $prod= $_POST['idpr'];

    $consultas= "DELETE FROM proveedor WHERE idProveedor=$prod";   
    $resulta= $conectar->query($consultas);
    if ($resulta) {
        echo "<SCRIPT >
    alert('!PROVEEDOR ELIMINADO¡');
    document.location=('../Vistas/Proveedor.php');
    </SCRIPT>";
    } else {
    
        echo "<SCRIPT >
    alert('!ERROR AL ELIMINAR EL PROVEEDOR¡');
    document.location=('../Vistas/Proveedor.php');
    
    </SCRIPT>";
    }


?>

