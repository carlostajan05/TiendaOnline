<?php

require "../conexion/conexion.php";
$consulta = mysqli_query( $conectar,"SELECT * FROM productos");
while($dat=mysqli_fetch_assoc($consulta)){
    $arra[]=$dat;
}
echo json_encode($arra);
exit;
exit;







?>