<?php

require "../conexion/conexion.php";
$consulta = mysqli_query( $conectar,"SELECT * FROM clientes");
while($dat=mysqli_fetch_assoc($consulta)){
    $arra[]=$dat;
}
echo json_encode($arra);
exit;

if($_POST['action'] == 'procesarVenta'){
    var_dump($_POST);
}

exit;







?>