
<?php
require ("../conexion/conexion.php");
if($_POST['action'] == 'info'){

if(!empty($_POST['cliente'])){
    $nit = $_POST['cliente'];
    $query = mysqli_query($conectar, "SELECT idProductos, Descripcion, Existencia, ValorPro, Provee FROM productos WHERE idProductos='$nit'");
    mysqli_close($conectar);
    $resul = mysqli_num_rows($query);
    $data = '';
    if($resul > 0){
        $data = mysqli_fetch_assoc($query);
    }else{
        $data=0;
    }
    echo json_encode($data,JSON_UNESCAPED_UNICODE);
}
exit;
}

//agregar campo











?>