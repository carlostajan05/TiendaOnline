<?php 
session_start();

require ("../conexion/conexion.php");
$busquedaclie='';
$fecha_de='';
$fecha_a='';

if(isset ($_REQUEST['busquedacli']) && $_REQUEST ['busquedacli'] =='' ){

        header("location: ../Vistas/Cliente.php");
    }


if(!empty($_REQUEST['busquedacli'])){
    if(!is_numeric($_REQUEST['busquedacli'])){
        header("location:  ../Vistas/Cliente.php");
    }
    $busquedaclie= strtolower($_REQUEST['busquedacli']);
    $wherec="ID =$busquedaclie";
    $buscar="busquedacli =$busquedaclie";
 
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
      <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
      <script src="../Bootstrap/js/jquery.js"></script>
    <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
   
    <script src="../Bootstrap/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="../Index.php">
                    <img src="../Images/logo2.png" width="70" height="70" alt="">
                </a>
            </div>
            <div class="barra1 col-md-10">
                <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
    <a class="nav-item nav-link"  href="../index.php" aria-selected="false"><span><img src="../Images/casa.png" alt=""></span>Inicio</a> 
    <a class="nav-item nav-link" href="NuevaFactura.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Facturas</a>
    <a class="nav-item nav-link active" href="Cliente.php" aria-selected="true"><span><img src="../Images/clientes.png" alt=""></span>Clientes</a>
    <a class="nav-item nav-link" href="productos.php" aria-selected="false"><span><img src="../Images/almacenamiento.png" alt=""></span>Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="../Images/clientes.png" alt=""></span>Proveedor</a>
    <a class="nav-item nav-link" href="Contactos.php"   aria-selected="false"><span><img src="../Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
                <a href="">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>
    <div class="row">
        <div class="contenido col-md-12">
        <div class="container">
        <div class="panel panel-info">

            <div class="panel-heading">
            <div class="btn-group pull-right">
                <button type='button' class="btn btn-info" data-toggle="modal" 
                data-target="#nuevoCliente"><i class="fas fa-car"></i>  Nuevo Cliente</button>
			</div>
            <h4><i class="fas fa-edit"></i>Clientes</h4>
            </div>

            <div class="panel-body">
                
                    <form class="form-horizontal" role="form">
                    <div class="form-group row">

						<label for="cli" class="col-md-2 control-label">Cliente</label>
							<div class="col-md-5">
              <form action="ListarCli.php" methodo=get  class="form_search_date">
            <input type="Text" name="busquedacl" placeholder="Nombre" value="<?php echo $busquedaclie; ?>">
            <button type="submit" class="btn_view"> buscar</button>
             </form>							</div>
             <?php
             require_once('../conexion/conexion.php');
   $regitro = mysqli_query($conectar," SELECT COUNT(*) as total_registro FROM clientes WHERE $wherec"); 
   $resultado= mysqli_fetch_array($regitro);
   $total_registro= $resultado['total_registro'];

   $por_pagina= 5;
   if(empty($_GET['paginas'])){
       $paginas=1;
   }else{
       $paginas=$_GET['paginas'];
   }
   $desde= ($paginas-1) * $por_pagina;
   $total_paginas = ceil($total_registro / $por_pagina);

   $con = mysqli_query($conectar," SELECT ID, Cedula, NombreCli,
   TipoCompra, TelCli, DireccCli FROM clientes WHERE $wherec ORDER BY ID DESC LIMIT $desde,$por_pagina"); 
 

   mysqli_close($conectar);
   $res= mysqli_num_rows($con);

   if($res > 0){
       while($data=mysqli_fetch_array($con)){
          
        ?>

    <td><?php echo $data['ID'];   ?></td>
    <td><?php  echo $data['Cedula'];  ?> </td>
    <td><?php  echo $data['NombreCli'];  ?> </td>
    <td><?php  echo $data['TipoCompra'];  ?> </td>
    <td><?php  echo $data['TelCli'];  ?> </td>
    <td><?php  echo $data['DireccCli'];  ?> </td>
   



</div> 
    </tr>
       
  <?php }

                 }          
                 ?>
       </table>
       <div class="paginador">
       <ul>
       <li><a href="#">|</a></li>
       <li><a href="#"><<</a></li>
     <?php 
     for($i=1; $i < $total_paginas; $i++){
         if($i == $paginas){
            echo '<li class="pageSelected">'.$i.'</li>';
         }else{
            echo '<li><a href="?paginas='.$i.'">'.$i.'</a></li>';

         }
        
     }
     ?>
      <li><a href="#">|</a></li>
       <li><a href="#">>></a></li>

       </ul>
</div>


                </body>
                      </html>
</body>
</html>