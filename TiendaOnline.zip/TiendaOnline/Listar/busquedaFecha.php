<?php 
session_start();

require ("../conexion/conexion.php");
$busqueda='';
$fecha_de='';
$fecha_a='';

if(isset ($_REQUEST['busqueda']) && $_REQUEST ['busqueda'] =='' ){

        header("location: ../Vistas/ListaVentas.php");
    }
    if(isset ($_REQUEST['fecha_de']) || isset($_REQUEST ['fecha_a'] ))
    {
        if($_REQUEST['fecha_de'] == '' || $_REQUEST ['fecha_a'] == ''){
        header("location: ../Vistas/ListaVentas.php");
    }
    }


if(!empty($_REQUEST['busqueda'])){
    if(!is_numeric($_REQUEST['busqueda'])){
        header("location: ../Vistas/ListaVentas.php");
    }
    $busqueda= strtolower($_REQUEST['busqueda']);
    $where="idVentas =$busqueda";
    $buscar="busqueda =$busqueda";
 
}

if(!empty($_REQUEST['fecha_de']) && !empty($_REQUEST['fecha_a'])){

$fecha_de=$_REQUEST['fecha_de'];
$fecha_a=$_REQUEST['fecha_a'];

$buscar='';

if($fecha_de > $fecha_a){
    header("location: ../Vistas/ListaVentas.php");
}else if($fecha_de=$fecha_a){
    $where ="FechaVen LIKE '$fecha_de%'";
    $buscar ="fecha_de=$fecha_de&fecha_a=$fecha_a";

}else{
    $f_de = $fecha_de.'00:00:00';
    $f_a = $fecha_a.' 23:59:59';
    $where = "fecha BETWEEN '$f_de' AND '$f_a'";
    $buscar = "fecha_de=$fecha_de&fecha_a=$fecha_a";
}




}
?>





<!DOCTYPE html> 
<html lang="es">
    <head>
<title> BusquedaFecha </title>
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
          <meta http-equiv="X-UA-Compatible" content="ie=edge">
          <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
    <link rel="shorcut icon" type="text/css" href="../images/logo1.png">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
      <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
      <script src="../Bootstrap/js/jquery.js"></script>   
    <script src="../Bootstrap/js/bootstrap.min.js"></script>


        </head>
        <body>
        <div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="../Index.php">
                    <img src="../Images/logo2.png" width="70" height="70" alt="">
                </a>
            </div>
            <div class="barra1 col-md-10">
          <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
    <a class="nav-item nav-link"  href="../index.php" aria-selected="false"><span><img src="../Images/casa.png" alt=""></span>Inicio</a> 
    <a class="nav-item nav-link" href="ListaVentas.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Ventas</a>
    <a class="nav-item nav-link" href="NuevaFactura.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Facturas</a>
    <a class="nav-item nav-link active" href="Cliente.php" aria-selected="true"><span><img src="../Images/clientes.png" alt=""></span>Clientes</a>
    <a class="nav-item nav-link" href="productos.php" aria-selected="false"><span><img src="../Images/almacenamiento.png" alt=""></span>Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="../Images/clientes.png" alt=""></span>Proveedor</a>
    <a class="nav-item nav-link" href="Contactos.php"   aria-selected="false"><span><img src="../Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
                <a href="">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>
    <div class="row">
        <div class="contenido col-md-12">
        <div class="container">
        <div class="panel panel-info">

            <div class="panel-heading">
        <div class="container">

    <div class="panel panel-info">
          <div class="panel-heading">
            <h4><i class="fas fa-edit"></i>Ventas</h4>
          </div>
            <div class="panel-body">
            <div class="form-group row">
            <div class="col-md-5">
            <form action="busquedaFecha.php" methodo=get  class="form_search_date">
            <input type="number" name="busqueda" placeholder="ID factura" class="form-control2" value="<?php echo $busqueda; ?>">
            </div>
<div class="col-md-3">
            <button type="submit" class="btn btn-primary2"> buscar</button>
             </form>
</div>
            
			
							<div class="col-md-5">
						

                            <h5>Buscar por fecha</h5>
                            <form action="busquedaFecha.php" methodo=get  class="form_search_date">
                           <label> De: </label>
                           <input type="date" name="fecha_de" id="fecha_de" value="<?php echo $fecha_de ?>" required>
                           <label> A: </label>
                           <input type="date" name="fecha_a" id="fecha_a" value="<?php echo $fecha_a ?>" required>
                           <button type="submit" class="btn_view"> buscar</button>
                            </form>
                            </div>

                           
                                             <div class="table-responsive">
                                                   <table class="table">

                                                    <thead class="info">
                                                    <tr>
                                                        <th> Id</th>
                                                        <th class="text-rigth">Fecha</th>
                                                        <th>Usuario</th>
                                                        <th>Cliente</th>
                                                        <th>Estado</th>
                                                        <th class="text-rigth">Valor Total </th>
                                                        <th class="text-rigth">Acciones </th>
                                                        </tr>
                                                    </thead>
                                             
                                                              </div>  
                                      
						    </div>                   

          <?php

   $regitro = mysqli_query($conectar," SELECT COUNT(*) as total_registro FROM factura WHERE $where "); 
   $resultado= mysqli_fetch_array($regitro);
   $total_registro= $resultado['total_registro'];

   $por_pagina= 5;
   if(empty($_GET['paginas'])){
       $paginas=1;
   }else{
       $paginas=$_GET['paginas'];
   }
   $desde= ($paginas-1) * $por_pagina;
   $total_paginas = ceil($total_registro / $por_pagina);

   $con = mysqli_query($conectar," SELECT factura.idVentas, factura.FechaVen, 
   factura.ValorTot, factura.Clientes_ID, usuario.NombreUsu as Vendedor, 
   clientes.NombreCli as cliente, clientes.TipoCompra FROM factura INNER JOIN usuario
    ON factura.usuario= usuario.Identificacion INNER JOIN clientes
     ON factura.Clientes_ID = clientes.ID WHERE $where ORDER BY factura.FechaVen DESC LIMIT $desde,$por_pagina"); 
 

   mysqli_close($conectar);
   $res= mysqli_num_rows($con);

   if($res > 0){
       while($data=mysqli_fetch_array($con)){
           if($data["TipoCompra"]=="contado"){
               $estado='<span class="pagada">Pagada</span>';
           }else{
            $estado='<span class="anulada">Por pagar</span>';
           }
        ?>

    <tr id ="row_<?php echo $data['idVentas'];   ?>">
    <td><?php echo $data['idVentas'];   ?></td>
    <td><?php  echo $data['FechaVen'];  ?> </td>
    <td><?php  echo $data['Vendedor'];  ?> </td>
    <td><?php  echo $data['cliente'];  ?> </td>
    <td><?php echo $estado;   ?> </td>
    <td class="text-right totalfactura"><span> $</span<><?php  echo $data['ValorTot'];  ?> </td>
    <td>
    <div class="div_acciones">
            <div>
            <a href="../factura/generaFactura.php? cl=<?php echo $data['Clientes_ID']; ?>
            &f=<?php echo $data['idVentas'];?>"  target="blank" type="submit" id="view_factura">PDF</a>
           
            </div>
            
   

    <?php 
    if($data["TipoCompra"]== "credito"){
        ?>
        <div class="div_factura">
        <button class="btn_anular anular_factura" type="hidden"  fac="<?php echo $data['idVentas'];?>">pagada</button>
        </div>
        <?php   }else{?>

            <div class="div_factura">
        <button class="btn_anular inactive" type="button" >pagada</button>
        </div>
<?php

        }
        ?>

</div> 
    </tr>
       
  <?php }

                 }          
                 ?>
       </table>
       <div class="paginador">
       <ul>
       <?php 
       if($paginas !=1){
           ?>
           <li><a href="?paginas=<?php echo 1; ?>&<?php echo $buscar;?>"></a></li>
           <li><a href="?paginas=<?php echo $paginas-1;?>"></a></li>
           <?php
       }
     for($i=1; $i < $total_paginas; $i++){
         if($i == $paginas){
            echo '<li class="pageSelected">'.$i.'</li>';
         }else{
            echo '<li><a href="?paginas='.$i. '$'.$buscar.'">'.$i.'</a></li>';

         }
        
     }
     if($paginas != $total_paginas){
         ?>
        <li><a href="?paginas=<?php echo  $paginas +1; ?>&<?php echo $buscar;?>"></a></li>
        <li><a href="?paginas=<?php echo $total_paginas;?>&<?php echo $buscar;?>"></a></li>
    <?php } ?>
     


       </ul>
</div>

                </body>
                      </html>


                       