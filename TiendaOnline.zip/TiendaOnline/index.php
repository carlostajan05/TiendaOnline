<?php session_start(); ?>


<!DOCTYPE html> 
<html lang="es">
    <head>
<title> Login </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
          <meta http-equiv="X-UA-Compatible" content="ie=edge">
          <link rel="shorcut icon" type="text/css" href="images/logo2.png">
          <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
          <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
          <link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.css">
          <link rel="stylesheet" type="text/css" href="Css/estilolo.css">
          
        </head>
        <body>

     <div class="modal-dialog text-center">
       <div class="col-sm-8 main-section">
         <div class="modal-content">
           <div class="col-12 user-img" >
           <img src="images/logo2.png">
         </div>
         <form action="conexion/ValidadLogin.php" method="POST">
        <form class="col-12">
            <div class="form-group" id="inputnumero">
              
                <label for="inputEmail">Usuario</label>
                <input type="number" class="form-control" name="user" placeholder="Usuario"> 
            </div>
            
            <div class="form-group" id="inputPassword">
                <label for="inputPassword">Contrasena</label>               
                <input type="password" class="form-control"  name="pass" placeholder="Password">
           


            </div>
          
            <button type="submit" name="login" class="btn btn-primary"> <i class="fas fa-sign-in-alt"></i>Entrar</button>
            </form>
        </form>      

    
           </div>
                 </div>

                   </div>
                     
        </body>
</html>