<?php
session_start();
session_destroy();
header("Location: /TiendaOnline/login.php");
