<?php  session_start();

require 'conexion.php';

  if (isset($_POST['login'])) {

    $user = $_POST['user'];
    $passw=$_POST['pass'];

    $consulta = "SELECT * FROM usuario WHERE Identificacion='$user' AND Password='$passw'";

    $resulatado = mysqli_query($conectar, $consulta);

    $fila = mysqli_num_rows($resulatado);
 if ($fila > 0) {

          
        $datos = $resulatado->fetch_assoc();
      
      $_SESSION['user'] = $fila['Identificacion'];
      $_SESSION['pass'] = $fila['Password'];
      $_SESSION['use'] = $datos;

      header("Location: ../Vistas/index.php");

    }else{
      echo 
        "<script type='text/javascript'>
          alert('Usuario o contraseña incorrectos.');
          window.location.pathname = '../proyectoFN/loguin.php';
        </script>";
        }
     
}


?>
