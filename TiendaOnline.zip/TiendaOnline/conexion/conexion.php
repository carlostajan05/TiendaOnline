<?php

//+++++++++++++++++++++++++BD LOCAL+++++++++++++++++++++++++
$host = "localhost";
$user = "root";
$pass = "";
$bd   = "mydb";

$conectar = mysqli_connect($host, $user, $pass, $bd);





// Check connection



?>