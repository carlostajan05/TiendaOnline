<?php

	//print_r($_REQUEST);
	//exit;
	//echo base64_encode('2');
	//exit;
	session_start();
	
	include "../conexion/conexion.php";
	require_once '../pdf/vendor/autoload.php';
	use Dompdf\Dompdf;

	if(empty($_REQUEST['cl']) || empty($_REQUEST['f']))
	{
		echo "No es posible generar la factura.";
	}else{
		$codClien = $_REQUEST['cl'];
		$noFactura = $_REQUEST['f'];
		$anulada = '';
		}
	
		$query = mysqli_query($conectar,"SELECT factura.idVentas,DATE_FORMAT(factura.FechaVen, '%d/%m/%Y')
		as fecha, DATE_FORMAT(factura.FechaVen,'%H:%i:%s') as  hora, 
	   factura.ValorTot, factura.Clientes_ID, usuario.NombreUsu as Vendedor, 
	   clientes.Cedula, clientes.TelCli, clientes.DireccCli,
	clientes.NombreCli, clientes.TipoCompra FROM factura INNER JOIN usuario
		ON factura.usuario= usuario.Identificacion INNER JOIN clientes
		 ON factura.Clientes_ID = clientes.ID WHERE factura.idVentas = $noFactura AND
		 factura.Clientes_ID = $codClien ");

		$result = mysqli_num_rows($query);
		if($result > 0){

			$factura = mysqli_fetch_assoc($query);
			$no_factura = $factura['idVentas'];

			if($factura['TipoCompra'] == "contado"){
				$anulada = '<img class="anulada" src="img/Pagado.png" alt="Anulada">';
			}

			$query_productos = mysqli_query($conectar,"SELECT productos.Descripcion,
			detalles_factura.Canti, 
			detalles_factura.precio_tmp,(detalles_factura.Canti * detalles_factura.precio_tmp) as precio_total 
			FROM factura INNER JOIN detalles_factura
			 ON factura.idVentas = detalles_factura.N_Factur 
			 INNER JOIN productos 
			 ON detalles_factura.Cod_prod = productos.idProductos WHERE
			factura.idVentas= $no_factura ");
			$result_detalle = mysqli_num_rows($query_productos);

			ob_start();
		    include(dirname('__FILE__').'/factura.php');
		    $html = ob_get_clean();

			// instantiate and use the dompdf class
			$dompdf = new Dompdf();

			$dompdf->loadHtml($html);
			// (Optional) Setup the paper size and orientation
			$dompdf->setPaper('letter', 'portrait');
			// Render the HTML as PDF
			$dompdf->render();
			ob_end_clean();
			// Output the generated PDF to Browser
			$dompdf->stream('factura_'.$noFactura.'.pdf',array('Attachment'=>0));
			exit;
		}
	
?>