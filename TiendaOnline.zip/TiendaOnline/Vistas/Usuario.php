<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shorcut icon" type="text/css" href="../Images/logo2.png">
    <title>Usuario</title>
    <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
</head>
<body>
<div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="../Index.php">
                    <img src="../Images/logo2.png" width="70" height="70" alt=""    a href="../conexion/logout.php">
                </a>
            </div>
            <div class="barra1 col-md-10">
                <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
    <a class="nav-item nav-link"  href="index.php" aria-selected="false"><span><img src="../Images/casa.png" alt=""></span>Inicio</a> 
    <a class="nav-item nav-link" href="ListaVentas.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Ventas</a>
    <a class="nav-item nav-link"  href="NuevaFactura.php" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Facturas</a>
    <a class="nav-item nav-link" href="Cliente.php"    aria-selected="true"><span><img src="../Images/clientes.png" alt=""></span>Clientes</a>
    <a class="nav-item nav-link active" href="productos.php" aria-selected="false"><span><img src="../Images/almacenamiento.png" alt=""></span>Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="../Images/clientes.png" alt=""></span>Proveedor</a>
    <a class="nav-item nav-link" href="Contacto.php"  aria-selected="false"><span><img src="../Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
                <a href="../conexion/logout.php">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>
    <div class="row">
        <div class="contenido col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade" id="nav-clientes" role="tabpanel" aria-labelledby="nav-clientes-tab">
                    
                </div>
            </div>
        </div>

    </div>    
    <div class="panel panel-info">
          <div class="panel-heading">
            <h4><i class="fas fa-edit"></i>Usuario</h4>
            <div class="btn-group pull-right">
                <button type='button' class="btn btn-info" data-toggle="modal" 
                data-target="#nuevoUsuario"><i class="fas fa-car"></i>  Nuevo Usuario</button>
			</div>
          </div>
            <div class="panel-body">
            <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
      <script src="../Bootstrap/js/jquery.js"></script>
    <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
   
    <script src="../Bootstrap/js/bootstrap.min.js"></script>
    
        
                                             <div class="table-responsive">
                                                   <table class="table">

                                                    <thead class="info">
                                                    <tr>
                                                        <th> Id</th>
                                                        <th class="text-rigth">Descripcion</th>
                                                        <th>Existencia</th>
                                                        <th>ValorProdcuto</th>
                                                        <th class="text-rigth">Acciones </th>
                                                        </tr>
                                                    </thead>
                                             
                                                              </div>  
                                      
						    </div>         
                <center>
                        <div class="modal fade" id="nuevoProducto" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" >
                            <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title">Nueva Producto</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <form action="../GuardarDatos/GuardarPro.php" method="post">
                                    <br>
                                    <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="idp"  id="idp" required="" placeholder="Codigo" >  
                                  </div>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="Descripcion"  required="" placeholder="Descripcion">  
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="Cantidad" required="" placeholder="Cantidad">
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="ValorPro"  required="" placeholder="Valor">
                                  </div>
                                  <div class="form-group">
                                    <input type=submit class="btn btn-info" value="Registro">
                                  </div> 
                                </form>
                              </div>
                            </div>
                        </div>
                        </center>
                        
</div>

</div>




<?php
          require_once('../conexion/conexion.php');
   $regitro = mysqli_query($conectar," SELECT COUNT(*) as total_registro FROM productos"); 
   $resultado= mysqli_fetch_array($regitro);
   $total_registro= $resultado['total_registro'];

   $por_pagina= 5;
   if(empty($_GET['paginas'])){
       $paginas=1;
   }else{
       $paginas=$_GET['paginas'];
   }
   $desde= ($paginas-1) * $por_pagina;
   $total_paginas = ceil($total_registro / $por_pagina);

   $con = mysqli_query($conectar," SELECT idProductos, Descripcion, Existencia, ValorPro 
   FROM productos ORDER BY idProductos  DESC LIMIT $desde,$por_pagina"); 
 

   mysqli_close($conectar);
   $res= mysqli_num_rows($con);
   if($res > 0){
    while($data=mysqli_fetch_array($con)){

     ?>


    <tr id ="row_<?php echo $data['idProductos'];   ?>">
    <td><?php echo $data['idProductos'];   ?></td>
    <td><?php echo $data['Descripcion'];   ?></td>
    <td><?php  echo $data['Existencia'];  ?> </td>
    <td><?php  echo $data['ValorPro'];  ?> </td>
    <td><div class="div_acciones">
    <button class ="link_delete" 
    idp="<?php echo $data['idProductos'];?>" href="#">eliminar</button>
            <div>
 </td>
           
    </tr>
    <?php }
   }

?>
       </table>
       <div class="paginador">
       <ul>
       <li><a href="#">|</a></li>
       <li><a href="#"><<</a></li>
     <?php 
     for($i=1; $i < $total_paginas; $i++){
         if($i == $paginas){
            echo '<li class="pageSelected">'.$i.'</li>';
         }else{
            echo '<li><a href="?paginas='.$i.'">'.$i.'</a></li>';

         }
        
     }
     ?>
      <li><a href="#">|</a></li>
       <li><a href="#">>></a></li>

       </ul>
</div>
<script type="text/javascript"> 
  
  $('.link_delete').click(function(){
  if(confirm("esta seguro que quieres eliminar")){
var idprod= $(this).attr('idp');
    $.ajax({  
          type:"POST",
            url:'../Eliminar/eliminarprodu.php',
      async :true,
            data: {idprod:idprod},
      success: function(response)

      {
          alert(data);
      },
      error: function(error) {

}


          });
        }

        });


    </script> 
</body>
</html>