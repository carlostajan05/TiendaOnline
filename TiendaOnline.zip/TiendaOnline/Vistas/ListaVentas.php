<?php session_start(); ?>
<!DOCTYPE html> 
<html lang="es">
    <head>
<title> Ventas </title>
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
          <meta http-equiv="X-UA-Compatible" content="ie=edge">
          <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
    <link rel="shorcut icon" type="text/css" href="../images/logo1.png">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
      <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
      <script src="../Bootstrap/js/jquery.js"></script>   
    <script src="../Bootstrap/js/bootstrap.min.js"></script>


        </head>
        <body>
        <div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="../Index.php">
                    <img src="../Images/logo2.png" width="70" height="70" alt="">
                </a>
            </div>
            <div class="barra1 col-md-10">
          <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
    <a class="nav-item nav-link"  href="index.php" aria-selected="false"><span><img src="../Images/casa.png" alt=""></span>Inicio</a> 
    <a class="nav-item nav-link" href="ListaVentas.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Ventas</a>
    <a class="nav-item nav-link" href="NuevaFactura.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Facturas</a>
    <a class="nav-item nav-link active" href="Cliente.php" aria-selected="true"><span><img src="../Images/clientes.png" alt=""></span>Clientes</a>
    <a class="nav-item nav-link" href="productos.php" aria-selected="false"><span><img src="../Images/almacenamiento.png" alt=""></span>Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="../Images/clientes.png" alt=""></span>Proveedor</a>
    <a class="nav-item nav-link" href="Contactos.php"   aria-selected="false"><span><img src="../Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
                <a href="../conexion/logout.php">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>
    <div class="row">
        <div class="contenido col-md-12">
        <div class="container">
        <div class="panel panel-info">

            <div class="panel-heading">
        <div class="container">

    <div class="panel panel-info">
          <div class="panel-heading">
            <h4><i class="fas fa-edit"></i>Ventas</h4>
          </div>
            <div class="panel-body">
            <div class="form-group row">
            <div class="col-md-5">
            <form action="../Listar/busquedaFecha.php" methodo=get  class="form_search_date">
            <input type="number" name="busqueda" placeholder="ID factura"  class="form-control2" value="<?php echo $busqueda; ?>">
</div>
<div class="col-md-3">
            <button type="submit"  class="btn btn-primary2"> buscar</button>
</div>
             </form>
            
			
							<div class="col-md-5">
						

                            <h5>Buscar por fecha</h5>
                            <form action="../Listar/busquedaFecha.php" methodo=get  class="form_search_date">
                           <label> De: 
                           <input type="date" name="fecha_de" id="fecha_de" class="form-control2" require></label>
                           <label> A: 
                           <input type="date" name="fecha_a" id="fecha_a" class="form-control2" require></label>
                           <button type="submit"class="btn btn-primary2"> buscar</button>
                            </form>
                            
                            </div>
                                             <div class="table-responsive">
                                                   <table class="table">

                                                    <thead class="info">
                                                    <tr>
                                                        <th> Id</th>
                                                        <th class="text-rigth">Fecha</th>
                                                        <th>Usuario</th>
                                                        <th>Cliente</th>
                                                        <th>Estado</th>
                                                        <th class="text-rigth">Valor Total </th>
                                                        <th class="text-rigth">Acciones </th>
                                                        </tr>
                                                    </thead>
                                             
                                                              </div>  
                                      
                            </div>      
</div>             

          <?php
          require_once('../conexion/conexion.php');
   $regitro = mysqli_query($conectar," SELECT COUNT(*) as total_registro FROM factura"); 
   $resultado= mysqli_fetch_array($regitro);
   $total_registro= $resultado['total_registro'];

   $por_pagina= 5;
   if(empty($_GET['paginas'])){
       $paginas=1;
   }else{
       $paginas=$_GET['paginas'];
   }
   $desde= ($paginas-1) * $por_pagina;
   $total_paginas = ceil($total_registro / $por_pagina);

   $con = mysqli_query($conectar," SELECT factura.idVentas, factura.FechaVen, 
   factura.ValorTot, factura.Clientes_ID, usuario.NombreUsu as Vendedor, 
   clientes.NombreCli as cliente, clientes.TipoCompra FROM factura INNER JOIN usuario
    ON factura.usuario= usuario.Identificacion INNER JOIN clientes
     ON factura.Clientes_ID = clientes.ID ORDER BY factura.FechaVen DESC LIMIT $desde,$por_pagina"); 
 

   mysqli_close($conectar);
   $res= mysqli_num_rows($con);

   if($res > 0){
       while($data=mysqli_fetch_array($con)){
           if($data["TipoCompra"]=="contado"){
               $estado='<span class="pagada">Pagada</span>';
           }else{
            $estado='<span class="anulada">Por pagar</span>';
           }
        ?>

    <tr id ="row_<?php echo $data['idVentas'];   ?>">
    <td><?php echo $data['idVentas'];   ?></td>
    <td><?php  echo $data['FechaVen'];  ?> </td>
    <td><?php  echo $data['Vendedor'];  ?> </td>
    <td><?php  echo $data['cliente'];  ?> </td>
    <td><?php echo $estado;   ?> </td>
    <td class="text-right totalfactura"><span> $</span<><?php  echo $data['ValorTot'];  ?> </td>
    <td>
    <div class="div_acciones">
            <div>
            <a href="../factura/generaFactura.php? cl=<?php echo $data['Clientes_ID']; ?>
            &f=<?php echo $data['idVentas'];?>"  target="blank" type="submit" id="view_factura">
            <i class='far fa-file' style='font-size:36px'></i></a>
           
            </div>
            
   

    <?php 
    if($data["TipoCompra"]== "credito"){
        ?>
        <div class="div_factura">
        <button class="btn_anular anular_factura" type="hidden"  fac="<?php echo $data['idVentas'];?>"></button>
        </div>
        <?php   }else{?>

            <div class="div_factura">
        <button class="btn_anular inactive" type="hidden" ></button>
        </div>
<?php

        }
        ?>

</div> 
    </tr>
       
  <?php }

                 }          
                 ?>
       </table>
       <div class="paginador">
       <ul>
       <li><a href="#">|</a></li>
       <li><a href="#"><<</a></li>
     <?php 
     for($i=1; $i < $total_paginas; $i++){
         if($i == $paginas){
            echo '<li class="pageSelected">'.$i.'</li>';
         }else{
            echo '<li><a href="?paginas='.$i.'">'.$i.'</a></li>';

         }
        
     }
     ?>
      <li><a href="#">|</a></li>
       <li><a href="#">>></a></li>

       </ul>
</div>


                </body>
                      </html>


                       