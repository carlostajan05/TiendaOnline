<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cliente</title>
    <link rel="shorcut icon" type="text/css" href="../Images/logo2.png">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
      <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
      <script src="../Bootstrap/js/jquery.js"></script>
    <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
   
    <script src="../Bootstrap/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="../Index.php">
                    <img src="../Images/logo2.png" width="70" height="70" alt=""
                       <a href="../conexion/logout.php">
                </a>
            </div>
            <div class="barra1 col-md-10">
                <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
    <a class="nav-item nav-link"  href="index.php" aria-selected="false"><span><img src="../Images/casa.png" alt=""></span>Inicio</a> 
    <a class="nav-item nav-link" href="NuevaFactura.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Facturas</a>
    <a class="nav-item nav-link active" href="Cliente.php" aria-selected="true"><span><img src="../Images/clientes.png" alt=""></span>Clientes</a>
    <a class="nav-item nav-link" href="productos.php" aria-selected="false"><span><img src="../Images/almacenamiento.png" alt=""></span>Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="../Images/clientes.png" alt=""></span>Proveedor</a>
    <a class="nav-item nav-link" href="Contactos.php"   aria-selected="false"><span><img src="../Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
                <a href="../conexion/logout.php">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>
    <div class="row">
        <div class="contenido col-md-12">
        <div class="container">
        <div class="panel panel-info">

            <div class="panel-heading">
            <div class="btn-group pull-right">
                <button type='button' class="btn btn-info" data-toggle="modal" 
                data-target="#nuevoCliente"><i class="fas fa-car"></i>  Nuevo Cliente</button>
			</div>
            <h4><i class="fas fa-edit"></i>Clientes</h4>
            </div>

            <div class="panel-body">
                
                    <form class="form-horizontal" role="form">
                    <div class="form-group row">

						<label for="cli" class="col-md-2 control-label">Cliente</label>
							
              <form action="../Listar/ListarCli.php" methodo=get  class="form_search_date">
              <div class="col-md-5">
            <input type="number" name="busquedacli" class="form-control" placeholder="Nombre" value="">
                  </div>
                  <div class="col-md-3">
            <button type="submit"  class="btn btn-primary"> buscar</button>
</div>
             </form>							</div>
                           
                                             <div class="table-responsive">
                                                   <table class="table">

                                                    <thead class="info">
                                                    <th>ID</th>
                                                      <th>Cliente</th>
                                                      <th>Tipo de Compra</th>
                                                      <th>Telefono</th>
                                                      <th>Direccion</th>
                                                      <th class="text-rigth">Acciones
                                                      </th>
                                                      
                                                    </thead>

                                                    <tbody id="tbody">
                                                    
                                                    </tbody>
                                                    
                                                    </table>
                                       
            
                                                              </div>  
                                      
						    </div>                   
                    </form>

                    <center>
                        <div class="modal fade" id="nuevoCliente" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" >
                            <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title">Nueva Cliente</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <form action="../GuardarDatos/GuardarClie.php" method="post">
                                    <br>
                                    <div class="form-group col-md-8">
                                    <input class="form-control" type="hidden" name="id_Cli"  id="id"  placeholder="Nombre">  
                                  </div>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="Nombre"  required="" placeholder="Nombre">  
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="Cedula"required="" placeholder="Documento de identidad">
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="Compra"  required="" placeholder="Tipo de Compra">
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="Telefono"  required="" placeholder="Telefono" >                
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="varchar" name="Direccion"  required="" placeholder="Direccion">  
                                  </div>
                                            <?php
                                                    include '../conexion/conexion.php';
                                                    $query = 'SELECT Identificacion, Password FROM usuario';
                                                    $result = $conectar->query($query);
                                                    ?>
                                                    <select name ="id"  id="id" style="visibility:hidden">  
                                                    
                                                        <?php    
                                                      while ( $row = $result->fetch_array() )    
                                                        {
                                                          ?>
                                                        <option value=" <?php echo $row['Identificacion'] ?> " >
                                                        <?php echo $row['Password']; ?>
                                                        </option>
                                                            
                                                        <?php
                                                        }    
                                                        ?>        
                                                    </select>
                      
                                  <div class="form-group">
                                    <input type=submit class="btn btn-info" value="Registro">
                                  </div> 
                                </form>
                              </div>
                            </div>
                        </div>

                      </center>
                      

                    <center>
                        <div class="modal fade" id="EditarCliente" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" >
                            <div class="modal-content">
                                <div class="modal-header">
                                <form class="form-horizontal" role="form" name="for_new_venta" id="for_new_venta" class="datos">
                                  <h5 class="modal-title">EditarCliente</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
               
                                    <br>
                                    <div class="form-group col-md-8">
                                    <input class="form-control" type="hidden" name="I"  id="I">  
                                  </div>
                                
                      


                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="Nombres"  id="Nombres"  placeholder="Nombre">  
                                  </div>
                                  <br>
                                  
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="Cedula" id="Cedula"   placeholder="Documento de identidad">
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="TipoCo" id="TipoCo"  placeholder="Tipo de Compra">
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="Tel" id="Tel"  placeholder="Telefono" >                
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="varchar" name="Direccion"  id="Direccion" placeholder="Direccion">  
                                  </div>
                                            <?php
                                                    include '../conexion/conexion.php';
                                                    $query = 'SELECT Identificacion, Password FROM usuario';
                                                    $result = $conectar->query($query);
                                                    ?>
                                                    <select name ="id"  id="id" style="visibility:hidden">  
                                                    
                                                        <?php    
                                                      while ( $row = $result->fetch_array() )    
                                                        {
                                                          ?>
                                                        <option value=" <?php echo $row['Identificacion'] ?> " >
                                                        <?php echo $row['Password']; ?>
                                                        </option>
                                                            
                                                        <?php
                                                        }    
                                                        ?>        
                                                    </select>
                      
                                  <div class="form-group">
                                    <input type=submit class="btn btn-info" value="guardar" onclick="guardar();">
                                  </div> 
                      </form>
                              </div>
                            </div>
                        </div>

                      </center>


                      
  

</div>

</div>



<script type="text/javascript">
//clientes
$(function () {
  tabla();    
});
function tabla() {
$.ajax({  
        type:"POST",
    url:'../Listar/ConsultaClie.php',
    success: function(res){
    var js= JSON.parse(res);
    var tabla;
    for(var i = 0; i < js.length; i++){
      dato= js[i].ID+"*"+js[i].NombreCli+"*"+js[i].Cedula+"*"+js[i].TipoCompra+"*"+js[i].TelCli+"*"+js[i].DireccCli+"*"+js[i].usuario_Identificacion;
     tabla+= '<tr><td>'+js[i].ID+'</td><td>'  +js[i].NombreCli+'</td><td>'+js[i].TipoCompra+'</td><td>'+js[i].TelCli+
     '</td><td>'+js[i].DireccCli+ "</td><td><button type='button' class='btn btn-primary' data-toggle='modal'  data-target='#EditarCliente' onclick='mostrar("+'"'+dato+'"'+");' ><i class='fas fa-edit'></i></a><button type='button' class='btn btn-primary'  title='Borrar cliente' id='eliminar' p='("+'"'+js[i].ID+'"'+");'  ><i class='fas fa-trash'></i></a></td></tr>";
    }
    $('#tbody').html(tabla);
    
    }
});

}


function mostrar(dato){


var d=dato.split("*");
              $("#I").val(d[0]);
            $("#Nombres").val(d[1]);
            $("#Cedula").val(d[2]);
            $("#TipoCo").val(d[3]);
            $("#Tel").val(d[4]);
            $("#Direccion").val(d[5]);
            $("#id").val(d[6]);
            

  
}

//guardar


function guardar(){
$('#for_new_venta').submit(function(){
  $.ajax({  
    type:"POST",
    url:'../GuardarDatos/oper.php',
    async :true,
    data: $('#for_new_venta').serialize(),
    success: function(response)
    {
      console.log(response);
      }



});

});
}
$('#eliminar').click(function(){
  if(confirm("esta seguro que quieres eliminar")){
var p= $(this).attr('ID');
console.log(p);
    $.ajax({  
          type:"POST",
            url:'../Eliminar/ElimarCliente.php',
      async :true,
            data: {p:p},
      success: function(response)

      {
          alert(data);
      },
      error: function(error) {

}


          });
        }

        });



</script>

</body>
</html>