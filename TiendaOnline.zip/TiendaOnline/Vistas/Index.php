<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shorcut icon" type="text/css" href="../Images/logo1.png">
    <title>Inicio</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
    <script src="../Bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="">
                    <img src="../Images/logo2.png" width="70" height="70" alt="" a href="../conexion/logout.php">
                </a>
            </div>
            <div class="barra1 col-md-10">
                <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
  <a class=" nav-link" href="#" ata-toggle="modal"  data-target="#nuevousuario">Usuario</a>
    <a class="nav-item nav-link" href="NuevaFactura.php"  aria-selected="true" ><span><img src="Images/Icono-fac.png" alt=""></span> Facturas</a>
    <a class="nav-item nav-link" href="ListaVentas.php"  aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Ventas</a>
    <a class="nav-item nav-link" href="Cliente.php"   aria-selected="false"><span><img src="Images/clientes.png" alt=""></span> Clientes</a>
    <a class="nav-item nav-link" href="productos.php" aria-selected="false"><span><img src="Images/almacenamiento.png" alt=""></span> Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="Images/clientes.png" alt=""></span>Proveedores</a>
    <a class="nav-item nav-link" href="Contactos.php" aria-selected="false"><span><img src="Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
              
                <a href="../conexion/logout.php">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>
        
    </div>
    <div class="container">
      <img class="img fluid" src="../Images/slide1.jpg" alt="">
    </div>

    <center>
                        <div class="modal fade" id="nuevousuario" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" >
                            <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title">Nueva Producto</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <form action="../GuardarDatos/GuardarPro.php" method="post">
                                    <br>
                                    <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="idp"  id="idp" required="" placeholder="Codigo" >  
                                  </div>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="Descripcion"  required="" placeholder="Descripcion">  
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="number" name="Cantidad" required="" placeholder="Cantidad">
                                  </div>
                                  <br>
                                  <div class="form-group col-md-8">
                                    <input class="form-control" type="text" name="ValorPro"  required="" placeholder="Valor">
                                  </div>
                                  <div class="form-group">
                                    <input type=submit class="btn btn-info" value="Registro">
                                  </div> 
                                </form>
                              </div>
                            </div>
                        </div>
                        </center>
                        
</body>
</html>