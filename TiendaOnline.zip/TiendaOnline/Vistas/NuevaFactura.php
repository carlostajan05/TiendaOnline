<?php session_start(); ?>
<!DOCTYPE html> 
<html lang="es">
    <head>
<title> Nueva Factura </title>
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
          <meta http-equiv="X-UA-Compatible" content="ie=edge">
          <link rel="shorcut icon" type="text/css" href="../Images/logo2.png">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
      <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
      <script src="../Bootstrap/js/jquery.js"></script>
    <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
   
    <script src="../Bootstrap/js/bootstrap.min.js"></script>


        </head>
        <body>

        <div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="../Index.php">
                    <img src="../Images/logo2.png" width="70" height="70" alt="">
                </a>
            </div>
            <div class="barra1 col-md-10">
                <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
    <a class="nav-item nav-link"  href="index.php" aria-selected="false"><span><img src="../Images/casa.png" alt=""></span>Inicio</a> 
    <a class="nav-item nav-link" href="ListaVentas.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Ventas</a>
    <a class="nav-item nav-link" href="NuevaFactura.php" role="tab" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Facturas</a>
    <a class="nav-item nav-link active" href="Cliente.php" aria-selected="true"><span><img src="../Images/clientes.png" alt=""></span>Clientes</a>
    <a class="nav-item nav-link" href="productos.php" aria-selected="false"><span><img src="../Images/almacenamiento.png" alt=""></span>Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="../Images/clientes.png" alt=""></span>Proveedor</a>
    <a class="nav-item nav-link" href="Contactos.php"   aria-selected="false"><span><img src="../Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
                <a href="../conexion/logout.php">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>

        <div class="container">

    <div class="panel panel-info">
          <div class="panel-heading">
            <h4><i class="fas fa-edit"></i>Nueva Venta</h4>
          </div>
            <div class="panel-body">

                
      <form class="form-horizontal" role="form" name="for_new_venta" id="for_new_venta" class="datos">

<button type="button" value="submit"class="btn btn-default2" id="nuevo"data-toggle="modal" data-target="#myModal">
        <i class="fas fa-save"></i> Nuevo Cliente
</button>
      <br>

    
 

    <div class="form-group row fila2">
           

            <div class="form-group col-md-8">
            <input class="form-control" type="hidden" name="id_Cli"  id="id_Cli" value="">  
            </div>  

  </div>

  <div class="form-group row fila1">

 <label for="nombre_cliente" class="col-md-1 control label" name="lista1">Cliente</label>
  <div class="col-mb-3">
      <input type="text" class="form-control input-sm ui-autocomplete-input" id="nombre_cliente" name="nom"
      placeholder="Selecciona un cliente" required=""  value="">
  </div>
  
 

  <label for="TipoC" class="col-md-1 control label">Compra</label>
  <div class="col-mb-2">
  <input type="text" class="form-control input-sm" id="TipoC" name="tipo" placeholder="Tipo Compra" disabled>
 </div>


  <label for="Telefono" class="col-md-1 control label">Telefono</label>
  <div class="col-mb-2"> 
  <input type="number" class="form-control input-sm" id="Telefono" name="tel" placeholder="Teléfono" disabled require="">
</div>





    </div>

    <div class="form-group row fila1">
    

    <label for="Documento" class="col-md-1 control label">Cedula</label>
  <div class="col-mb-2">
  <input type="number" class="form-control input-sm" id="Documento" name="cel" placeholder="Cedula" disabled>
</div>

    <label for="Direccion" class="col-md-1 control label">Direccion</label>
  <div class="col-mb-2">
  <input type="text" class="form-control input-sm" id="Direccion" name="dir" placeholder="Direccion" disabled>
    </div>
  

    <label for="fecha" class="col-md-1 control label">Fecha</label>
    <div class="col-mb-2">
    <input type="date" class="form-control input-sm" id="fechaActual" placeholder="Fecha" disabled >
      </div>


    </div> 
    
  
  <div class="form-group row">
  
  <?php
                                        include '../conexion/conexion.php';
                                        $query = 'SELECT Identificacion, Password FROM usuario';
                                        $result = $conectar->query($query);
                                        ?>
                                        <select name ="id"  id="id" style="visibility:hidden">  
                                        
                                            <?php    
                                          while ( $row = $result->fetch_array() )    
                                            {
                                              ?>
                                            <option value=" <?php echo $row['Identificacion'] ?> " >
                                            <?php echo $row['Password']; ?>
                                            </option>
                                                
                                            <?php
                                            }    
                                            ?>        
                                        </select>
                                        </form>



<div class="col-md-12">
        <div class="pull-right">
            <button type="submit" class="btn btn-info" id="div_registro_cliente"  data-toggle="modal" data-target="#">
                <i class="fas fa-car"></i> Guardar Cliente
            </button>

           
   
         </div>	
</div>


  
         
            </div>
    </div>

        </div>

        <div class="panel3 panel-info">
       
        <a href="#" class='btn btn-info' id="Factura-venta"><i class='fas fa-edit'></i>Procesar Factura</a>                    
                                          </div>
        <div class="container">


<div class="panel2 panel-info2">
      <div class="panel-heading2">
        <h4><i class="fas fa-edit"></i>Factura</h4>
      </div>
        <div class="panel-body">
        <form class="form-horizontal" role="form">
                    <div class="form-group row">
                
              
                                              <div class="table-responsive">
                                             <table class="table table-striped">

                                                      <thead class="primary">
                                                        <tr>
                                                        <th>Codigo</th>
                                                        <th>Descripcion</th>
                                                        <th>Existencia</th>
                                                        <th>cantidad</th>
                                                        <th>Precio</th>
                                                        <th>Precio Total</th>
                                                        <th class="text-rigth">Acciones
                                                        </tr>
                                                        <tr>
                                                        <th><input type="text" class="Campo" id="Codigo"></th>
                                                        <th id="desc">--</th>
                                                        <th id="exist">--</th>
                                                        <th><input type="text" class="Campo"id="Cantidad" value="0"  min="1" disabled></th>
                                                        <th id="Precio" > 0,00</th>
                                                        <th id="PrecioTotal">0,0</th>
                                                        <th><a href="#" id="acciones" class ="link_add"></i> Agregar</a></th>

                                                        </tr>
                                                        <thead class="primary">
                                                        <tr>
                                                        <th>Codigo</th>
                                                        <th>cantidad</th>
                                                        <th>Precio</th>
                                                        <th>Descripcion</th>
                                                        <th>Precio Total</th>
                                                        <th class="text-rigth">Acciones
                                                        
                                                        </th>
                                                        </tr>


                                                      </thead>

                                                      <tbody id="tbody">
                                                    

                                                      </tbody>
                                                      
                                                      <tbody id="tbodyTotal">
                                                      

                                                      </tbody>

                                                      </table>
                                                      </div>
                                      
              
                                                              </div>  
                                      
						    </div>                   
                    </form>
                                          </div>
                                          </div>
  
     
 

  



  <script src="../Js/datos.js"> </script> 
  <script type="text/javascript">
  $(document).ready(function(){
  var usuarios = '<?php echo session_id(); ?>';
   serchForDetalle(usuarios);
});
</script>


            </body>
                      </html>


                       