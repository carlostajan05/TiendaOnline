<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contactos</title>
    <link rel="stylesheet" href="../Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../Css/estilos.css">
</head>
<body class="Contactos">
<div class="container-fluid ">
        <div class="row bg-light">
            <div class="logo col-md-1">
                <a href="../Index.php">
                    <img src="../Images/logo2.png" width="70" height="70" alt="">
                </a>
            </div>
            <div class="barra1 col-md-10">
                <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-center">
  <div class="nav nav-tabs " id="nav-tab" role="tablist">
    <a class="nav-item nav-link"  href="index.php" aria-selected="false"><span><img src="../Images/casa.png" alt=""></span>Inicio</a> 
    <a class="nav-item nav-link"  href="NuevaFactura.php" aria-selected="false"><span><img src="../Images/Icono-fac.png" alt=""></span>Facturas</a>
    <a class="nav-item nav-link" href="Cliente.php"    aria-selected="true"><span><img src="../Images/clientes.png" alt=""></span>Clientes</a>
    <a class="nav-item nav-link" href="productos.php" aria-selected="false"><span><img src="../Images/almacenamiento.png" alt=""></span>Productos</a>
    <a class="nav-item nav-link" href="Proveedor.php" aria-selected="false"><span><img src="../Images/clientes.png" alt=""></span>Proveedor</a>
    <a class="nav-item nav-link active" href="Contacto.php"  aria-selected="false"><span><img src="../Images/contacto.png" alt=""></span>Contactenos</a>
  </div>
                </nav>
            </div>
            <div class="logo2 col-md-1 " >
                <a href="../conexion/logout.php">
                    <img src="../images/user.png" width="70" height="70" alt="">
                </a>
            </div>
        </div>
        <br><br>
 
    <div class="contenido-fluid Cont">
        <div class="row">
            <div class="col-md-3">
                <div class="card" style="width: 15rem; height:26rem;">
                    <img src="../Images/user.png" class="card-img-top" alt="50">
                    <div class="card-body">
                        <h5 class="card-title">Carlos Tajan - Yogen Padilla</h5>
                        <p class="card-text" style="color:black;">estudiantes de Ingeniería de Sistemas, sexto semestre</p>
                    </div>
                </div>
            </div>
            <div class="text-center col-md-6" >
                <br><br><br><br><br><br><br>   
                <p>Este es un software desarrollado por estudiantes de la Universidad De Córdoba,
                    el cual ha sido creado con el proposito de mejorar los procesos de invetariado.
                </p>
                <br><br><br><br><br><br><br><br>
            </div>
            
        </div>

    </div>  
    <div class="row">
        <div class="foo-Conta col-md-12 d-flex justify-content-center">
            <footer>
                © 2021 Copyright - Carlos Tajan - Yogen Padilla
            </footer>
        </div>
    </div>
</div>  


<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>