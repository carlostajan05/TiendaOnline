<?php session_start();?>
<?php
require ("conexion.php");
$nmero= $_POST['nmero'];
$codClien=$_POST['codClien'];
if($_POST['action'] == 'infor'){
 

    $session_id= session_id();
    $consulta = mysqli_query($conectar," SELECT * FROM detalle_temp WHERE session_id='$session_id'"); 
		$resultado= mysqli_num_rows($consulta);
 
        if( $resultado > 0){

        $consu = mysqli_query($conectar," CALL procesar_venta($nmero, $codClien,'$session_id')"); 
        $resulta= mysqli_num_rows($consu);
        
        if($resulta > 0){
                $data = mysqli_fetch_assoc($consu);
                echo json_encode($data,JSON_UNESCAPED_UNICODE);

        }else{
            echo "error";
        }
        
        }else{
            echo "error";
        }
            mysqli_close($conectar);
            exit;

}
?>