$(document).ready(function(){
   


//crear cliente 
$('#for_new_venta').submit(function(e){
  e.preventDefault();

    $.ajax({  
          type:"POST",
			url:'../GuardarDatos/datoscli.php',
      async :true,
			data: $('#for_new_venta').serialize(),
			success: function(response)
      {
        if(response != 'error'){
          $('#TipoC' ).attr('disabled','disabled');
              $('#Telefono' ).attr('disabled','disabled');
              $('#Documento' ).attr('disabled','disabled');
							$('#Direccion' ).attr('disabled','disabled');
             //ocultar boton agregar
             $('.btn-default2').slideUp();
          //ocultar el boton guardar
          $('#div_registro_cliente').slideUp();
        }
      
      },
      error: function(error) {

}

          });

        });



//fecha
window.onload = function(){
  var fecha = new Date(); //Fecha actual
  var mes = fecha.getMonth()+1; //obteniendo mes
  var dia = fecha.getDate(); //obteniendo dia
  var ano = fecha.getFullYear(); //obteniendo año
  if(dia<10)
    dia='0'+dia; //agrega cero si el menor de 10
  if(mes<10)
    mes='0'+mes //agrega cero si el menor de 10
  document.getElementById('fechaActual').value=ano+"-"+mes+"-"+dia;
}

    //activar los campos
    $('.btn-default2').click(function(e){
      e.preventDefault();
           
              $('#Telefono' ).removeAttr('disabled');
              $('#TipoC' ).removeAttr('disabled');
              $('#Documento' ).removeAttr('disabled');
							$('#Direccion' ).removeAttr('disabled');
              $('#div_registro_cliente').slideDown();

    });


//buscar cliente
		$('#nombre_cliente').keyup(function(e){
      e.preventDefault();
      var cl = $(this).val();
      var action ='searchCliente';
       	$.ajax({  
          type:"POST",
			url:'../GuardarDatos/datos.php',
      async :true,
			data: {action:action, cliente:cl },
			success:function(response)
      {
				console.log(response);
        if(response == 0){
               $('#TipoC' ).val('');
              $("#Telefono" ).val('');
							$("#Documento" ).val('');
							$("#Direccion" ).val('');
              //mostrar boton agregar
              $('.btn-default2').slideDown();
        }else{
          var data = $.parseJSON(response);
              $("#id_Cli" ).val(data.ID);
              $("#Telefono" ).val(data.TelCli);
              $('#TipoC' ).val(data.TipoCompra);
							$("#Documento" ).val(data.Cedula);
							$("#Direccion" ).val(data.DireccCli);
              $("#vendedor" ).val(data.usuario_Identificacion);
              //ocultar boton agregar
              $('.btn-default2').slideUp();
              $("#id_Cli" ).attr('disabled','disabled');
              $('#TipoC' ).attr('disabled','disabled');
              $('#Telefono' ).attr('disabled','disabled');
              $('#Documento' ).attr('disabled','disabled');
							$('#Direccion' ).attr('disabled','disabled');
              
              //ocultar el boton guardar
              $('#div_registro_cliente').slideUp();
        }
			},
      error: function(error) {

      }

          });
		});

//mostrar producto




//llenar productos
$('#Cantidad').keyup(function(e){
  e.preventDefault();

var PrecioTo = $(this).val() * $('#Precio').html();
var Exist = $('#exist').html();
console.log(Exist);
$('#PrecioTotal').html(PrecioTo);

if( ($(this).val() < 1 || isNaN($(this).val())) || ($(this).val() > Exist)   ){
  alert("Producto agostado o incorrecto");
  $('#acciones').slideUp();

}else{

  $('#acciones').slideDown();
}
  
});


//buscar productos
$('#Codigo').keyup(function(e){
  e.preventDefault();
  var producto = $(this).val();
  var action = 'info';
  if( producto != ''){
    $.ajax({  
          type:"POST",
			url:'../Listar/ConsultarProductoFa.php',
			async:true,
      data : {action:action,cliente:producto},
      success: function(response){
        console.log(response);
        if(response==0){

              $("#exist").html('-')
              $("#desc" ).html('-');
              $('#Cantidad' ).val('0');
							$("#Precio" ).html('00');
							$("#PrecioTotal" ).html('00');
              
              //ocultar el boton guardar
              
              $('#Cantidad' ).attr('disabled','disabled');
              $('#acciones').slideUp();
         
        }else{
          var data = JSON.parse(response);
              $("#desc" ).html(data.Descripcion);
              $("#exist").html(data.Existencia)
              $('#Cantidad' ).val('');
							$("#Precio" ).html(data.ValorPro);
							$("#PrecioTotal" ).html(data.ValorPro);
              //Activar Cantidad
              $('#Cantidad' ).removeAttr('disabled');
                //mostrar el boton agregar
                $('#acciones').slideDown();
        }
               
        },

  error: function(error){

  }
});
    }

  

});

//agregar producto al detalle de factura

$('#acciones').click(function(e){
  e.preventDefault();
 

if($('#Cantidad').val() > 0)
{
     var codi =  $("#Codigo" ).val();
      var canti =$('#Cantidad' ).val();
      var pres =  $('#Precio' ).html();
      var action = 'addproducto';

    $.ajax({  
          type:"POST",
			url:'../GuardarDatos/Detalle.php',
			async:true,
      data : {action:action,producto:codi,canti,pres},
      success: function(datos){
    if(datos != 'error'){
      var act =JSON.parse(datos);
       $('#tbody').html(act.detalle);
       $('#tbodyTotal').html(act.totales);

              $("#Codigo" ).val('');
              $("#exist").html('-')
              $("#desc" ).html('-');
              $('#Cantidad' ).val('0');
							$("#Precio" ).html('00');
							$("#PrecioTotal" ).html('00');
              
              //ocultar el boton guardar
              
              $('#Cantidad' ).attr('disabled','disabled');
              $('#acciones').slideUp();

    }else{
      console.log('no dato');
    }
    },
    error: function(error){

    }

		
	
});
}
});


//datos
$('#Factura-venta ').click(function(e){
      e.preventDefault();

		  var id_cliente = $("#nombre_cliente").val();
		  
		  if (id_cliente==""){
			  alert("Debes seleccionar un cliente");
			  $("#nombre_cliente").focus();
			  return false;
      }
    
  });

//pagado




 

  //facturar venta
  $('#Factura-venta').click(function(e){
      e.preventDefault();
  var rows= $('#tbody').length;
  if( rows > 0){
  var action = 'infor';
  var codClien= $('#id_Cli').val();
  console.log(codClien);
  var nmero = $('#id').val();
  
    $.ajax({  
          type:"POST",
			url:'../GuardarDatos/FacturarVenta.php',
			async:true,
      data : {action:action,codClien,nmero},
      success: function(responses){

  
      if(responses != 'error'){
        var inform =JSON.parse(responses);
        //console.log(inform);
      generarPDF(inform.Clientes_ID,inform.idVentas)
         location.reload();
       }else{
        console.log("no dato");
        }
        
        },
        error: function(error){

}

      });
    }
    });



    //ver factura pdf
  $('#view_factura').submit(function(e){
    e.preventDefault();
    var Clientes_ID= $(this).attr('cl');
    var idVentas =$(this).attr('f');
    generarPDF(Clientes_ID,idVentas)
  
    location.reload();
  
    });

//eliminar producto





});

function del_product_detalle (correlativo){
  var action='del_product_detalle';
  var id_detalle= correlativo;
  $.ajax({  
      type:"POST",
        url:'../GuardarDatos/eliminarProdTemp.php',
        async:true,
  data : {action:action,id_detalle:id_detalle},
  success: function(informacion){
    if(informacion != 'error'){
      var actio= JSON.parse(informacion);

       $('#tbody').html(actio.detalle);
       $('#tbodyTotal').html(actio.totales);

              $("#Codigo" ).val('');
              $("#exist").html('-')
              $("#desc" ).html('-');
              $('#Cantidad' ).val('0');
							$("#Precio" ).html('00');
							$("#PrecioTotal" ).html('00');
              
              //ocultar el boton guardar
              
              $('#Cantidad' ).attr('disabled','disabled');
              $('#acciones').slideUp();

    }else{
      $('#tbody').html('');
      $('#tbodyTotal').html('');
    }

    },
    error: function(error){

    }

    
  
});

}

    
function serchForDetalle(id){
    var action='serchForDetalle';
    var use=id;
    $.ajax({  
        type:"POST",
          url:'../GuardarDatos/Datostemp.php',
          async:true,
    data : {action:action,use:use},
    success: function(datos){
      if(datos != 'error'){
        var act =JSON.parse(datos);
         $('#tbody').html(act.detalle);
         $('#tbodyTotal').html(act.totales);
      }else{
        console.log('no dato');
      }
      },
      error: function(error){
  
      }
  
      
    
  });
  }


  function generarPDF(cliente,factura){
    var ancho=3000;
    var alto= 800;
    var x =parseInt((window.screen.width/2) - (ancho/2));
    var y =parseInt((window.screen.height/2) - (alto/2));
    $url ='../factura/generaFactura.php?cl='+cliente+'&f='+factura;
    window.open($url,"Factura","left="+x+",top="+y+ ",height="+alto+",scrollbar=si, location=no,resizable=si,menubar=no")
  }

  