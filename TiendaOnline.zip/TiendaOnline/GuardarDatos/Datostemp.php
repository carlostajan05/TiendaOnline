<?php session_start();?>
<?php
require ("../conexion/conexion.php");

//extraer campo

if($_POST['action'] == 'serchForDetalle'){

    if(empty($_POST['use'])){
        echo 'error';
    }else{
        
    $session_id= session_id();

    $llamda = mysqli_query($conectar," SELECT detalle_temp.correlativo, 
    detalle_temp.Cod_prod, detalle_temp.Canti, detalle_temp.precio_tmp, productos.descripcion 
    FROM detalle_temp INNER JOIN productos 
    ON detalle_temp.Cod_prod = productos.idProductos
    WHERE detalle_temp.session_id ='$session_id'"); 


        $resultado= mysqli_num_rows($llamda);
        $detalles='';
        $subtotal =0;
        $total =0;
        $arrayData =array();
        if($resultado > 0){

        while ($data =mysqli_fetch_assoc($llamda)){
            $precio_total= round($data['Canti'] * $data['precio_tmp'],2);
            $subtotal=round($subtotal + $precio_total,2);
            $total =round($total + $precio_total,2);

            $detalles.='<tr>
                                <td>'.$data['Cod_prod'].'</td>
                                <td class ="text-rigth">'.$data['Canti'].'</td>                         
                                <td class ="text-left">'.$data['precio_tmp'].'</td>
                                <td colspan="1">'.$data['descripcion'].'</td>   
                                <td class ="text-rigth">'.$precio_total.'</td>
                                <td class="text-rigth">
                                <button class= "btn btn-default" onclick="event.preventDefault();
								del_product_detalle ('.$data['correlativo'].')";class ="link_add">eliminar</button>
								</td>
                                </tr>';
        }
        $detalletabla ='
        <tr>
        <td class="text-right" colspan=4>SUBTOTAL $</td>
        <td class="text-left">'.$subtotal.'</td>
        <td></td>
    </tr>
    
    <tr>
        <td class="text-right" colspan=4>TOTAL $</td>
        <td class="text-left">'.$total.'</td>
        <td></td>
    </tr>';
    $arrayData['detalle'] =$detalles;
    $arrayData['totales'] =$detalletabla;
    echo json_encode($arrayData,JSON_UNESCAPED_UNICODE);

    
    
    }else{
        echo 'error';
        mysqli_close($conectar);
    }
    exit;
}
}
exit;

if($_POST['action'] == 'infor'){

}
?>