<?php session_start();?>
<?php
require ("../conexion/conexion.php");


//agregar campo
if($_POST['action'] == 'addproducto'){

	
	$pres= $_POST['pres'];

    if(empty($_POST['producto']) || empty($_POST['canti'])){
		echo 'error';
	}else{
		$codi= $_POST['producto'];
	$canti= $_POST['canti'];
	$session_id= session_id();


		$consulta = mysqli_query($conectar," CALL add_detalle_temp($codi, $canti,'$session_id')"); 
		$resultado= mysqli_num_rows($consulta);
		$detalles='';
		$subtotal =0;
		$total =0;
		$arrayData =array();
		if($resultado > 0){

		while ($data =mysqli_fetch_assoc($consulta)){
			$precio_total= round($data['Canti'] * $data['precio_tmp'],2);
			$subtotal=round($subtotal + $precio_total,2);
			$total =round($total + $precio_total,2);

			$detalles.='<tr>
								<td>'.$data['Cod_prod'].'</td>
								<td class ="text-rigth">'.$data['Canti'].'</td>							
								<td class ="text-left">'.$data['precio_tmp'].'</td>
								<td colspan="1">'.$data['descripcion'].'</td>	
								<td class ="text-rigth">'.$precio_total.'</td>
								<td class="text-rigth">
                                <button class= "btn btn-default" onclick="event.preventDefault();
								del_product_detalle ('.$data['correlativo'].')";class ="link_add">eliminar</button>
								</td>
								</tr>';
		}
		$detalletabla ='
		<tr>
		<td class="text-right" colspan=4>SUBTOTAL $</td>
		<td class="text-left">'.$subtotal.'</td>
		<td></td>
	</tr>
	
	<tr>
		<td class="text-right" colspan=4>TOTAL $</td>
		<td class="text-left">'.$total.'</td>
		<td></td>
	</tr>';
	$arrayData['detalle'] =$detalles;
	$arrayData['totales'] =$detalletabla;
	echo json_encode($arrayData,JSON_UNESCAPED_UNICODE);

	
	
	}else{
		echo 'error';
		mysqli_close($conectar);
	}
	exit;
}
}
exit;
