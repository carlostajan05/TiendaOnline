<?php

require "../conexion/conexion.php";
$id   = $_POST['id_Cli'];
$ced   = $_POST['Cedula'];
$name = $_POST['Nombre'];
$comp = $_POST['Compra'];
$tel = $_POST['Telefono'];
$Dir = $_POST['Direccion'];
$id_1 = $_POST['id'];



$sql2 = "INSERT INTO clientes (ID,Cedula, NombreCli, TipoCompra, TelCli, DireccCli,usuario_Identificacion)
 VALUES ('$id','$ced','$name','$comp','$tel','$Dir','$id_1')";
//var_dump($sql2);
$ins = $conectar->query($sql2);

if ($ins) {
    echo "<SCRIPT >
alert('!NUEVO USUARIO REGISTRADO ¡');
document.location=('Cliente.php');
</SCRIPT>";
} else {

    echo "<SCRIPT >
alert('!ERROR AL REGISTRAR NUEVO USUARIO¡');
document.location=('Cliente.php');

</SCRIPT>";
}
?>