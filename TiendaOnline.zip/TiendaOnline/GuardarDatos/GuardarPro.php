<?php

require "../conexion/conexion.php";
$idp   = $_POST['idp'];
$des   = $_POST['Descripcion'];
$can = $_POST['Cantidad'];
$val = $_POST['ValorPro'];



$sql2 = "INSERT INTO productos (idProductos,Descripcion, Existencia, ValorPro)
 VALUES ('$idp','$des','$can','$val')";
//var_dump($sql2);
$ins = $conectar->query($sql2);

if ($ins) {
    echo "<SCRIPT >
alert('!NUEVO PRODUCTO REGISTRADO ¡');
document.location=('../Vistas/productos.php');
</SCRIPT>";
} else {

    echo "<SCRIPT >
alert('!ERROR AL REGISTRAR PRODUCTO¡');
document.location=('../Vistas/productos.php');

</SCRIPT>";
}
?>