<?php

require "../conexion/conexion.php";


$ID=$_POST['id_Cli'];
$Nom =$_POST['nom'];
$Ced=$_POST['cel'];
$Tipo=$_POST['tipo'];
$Tel =$_POST['tel'];
$Dir=$_POST['dir'];
$id_1=$_POST['id'];

$consulta = "INSERT INTO clientes( ID,Cedula, NombreCli, 
TipoCompra, TelCli, DireccCli,usuario_Identificacion)VALUES ('$ID','$Ced','$Nom','$Tipo','$Tel','$Dir','$id_1')";

$ins = $conectar->query($consulta);

exit;