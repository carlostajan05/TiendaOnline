<?php

require "../conexion/conexion.php";
$idpr   = $_POST['idpr'];
$nopr = $_POST['NombrePro'];
$dir = $_POST['DirecPro'];
$te = $_POST['TelPro'];



$sql2 = "INSERT INTO proveedor (idProveedor,NombreProvee, DireccProvee, TelProvee)
 VALUES ('$idpr','$nopr','$dir','$te')";
//var_dump($sql2);
$ins = $conectar->query($sql2);

if ($ins) {
    echo "<SCRIPT >
alert('!NUEVO PROVEEDOR REGISTRADO ¡');
document.location=('../Vistas/Proveedor.php');
</SCRIPT>";
} else {

    echo "<SCRIPT >
alert('!ERROR AL REGISTRAR EL PROVEEDOR¡');
document.location=('../Vistas/Proveedor.php');

</SCRIPT>";
}
?>