<?php

require "../conexion/conexion.php";



if($_POST['action'] == 'searchCliente'){

    if(!empty($_POST['cliente'])){
        $nit = $_POST['cliente'];
        $query = mysqli_query($conectar, "SELECT ID, Cedula, NombreCli, TipoCompra, TelCli, DireccCli,usuario_Identificacion 
        FROM clientes WHERE NombreCli='$nit'");
        mysqli_close($conectar);
        $resul = mysqli_num_rows($query);
        $data = '';
        if($resul > 0){
            $data = mysqli_fetch_assoc($query);
        }else{
            $data=0;
        }
        echo json_encode($data,JSON_UNESCAPED_UNICODE);
    }
    exit;
}
exit;




?>