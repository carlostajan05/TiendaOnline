<?php
require ("../conexion/conexion.php");

$id_Cli=$_POST['I'];
$Cedula=$_POST['Cedula'];
$Nombres=$_POST['Nombres'];
$TipoCo=$_POST['TipoCo'];
$Tel=$_POST['Tel'];
$Direccion=$_POST['Direccion'];



$sql2 = "UPDATE clientes SET Cedula='$Cedula', NombreCli='$Nombres', 
TipoCompra='$TipoCo', TelCli='$Tel', DireccCli='$Direccion'  Where (ID='$id_Cli')";
$ins = $conectar->query($sql2);

if ($ins)
{
echo "<SCRIPT >	alert('SE HAN ACTUALIZADO SUS DATOS :v ¡');
    document.location=('Clientes.php'); </SCRIPT>";
} else {

echo "<SCRIPT > alert('!ERROR¡');
document.location=('Clientes.php');
</SCRIPT>";
}

exit;
exit;







?>