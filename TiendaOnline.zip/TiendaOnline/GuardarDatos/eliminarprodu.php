<?php session_start();?>
<?php
require ("../conexion/conexion.php");

    
    $producto_id= $_POST['idprod'];

    $consultas= mysqli_query($conectar,"DELETE FROM productos WHERE idProductos=$producto_id");   
    $resulta= mysqli_num_rows($consultas);
    if ($resulta) {
        echo "<SCRIPT >
    alert('!PRODUCTO REGISTRADO ¡');
    document.location=('Productos.php');
    </SCRIPT>";
    } else {
    
        echo "<SCRIPT >
    alert('!ERROR AL REGISTRAR EL PRODUCTO¡');
    document.location=('Productos.php');
    
    </SCRIPT>";
    }


?>


